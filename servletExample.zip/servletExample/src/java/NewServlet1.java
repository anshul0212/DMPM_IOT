/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
/**
 *
 * @author 1013066
 */
public class NewServlet1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             String json=request.getParameter("json");
             JSONParser parser = new JSONParser(); 
             
             //{"gender":"female","name":"gdgdrh","age":"10"}
             JSONObject jsonObj = (JSONObject) parser.parse(json);
             String name = String.valueOf(jsonObj.get("name"));  
             String gender = String.valueOf(jsonObj.get("gender"));
             String age = String.valueOf(jsonObj.get("age"));
             String marks=String.valueOf(jsonObj.get("marks"));
            JSONArray marksArr = (JSONArray)parser.parse(marks);
                    
                               JSONObject jsonObj1 = (JSONObject)parser.parse(String.valueOf(marksArr.get(0)));
                             String mark1= String.valueOf(jsonObj1.get("English"));
                             String mark2= String.valueOf(jsonObj1.get("Maths"));
                             String mark3= String.valueOf(jsonObj1.get("Physics"));
                             String mark4= String.valueOf(jsonObj1.get("Chemistry"));
                         
                   
            
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet NewServlet1</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet NewServlet1 at " + request.getContextPath() + "</h1>");
            out.println("<p> Name : "+ name +"<br> Age : "+ age + "<br> Gender: " + gender +"<br> </p>");
            out.println("<p> Marks -----  English : "+ mark1 +"<br> Maths : "+ mark2 + "<br> Physics: " + mark3 +"<br> Chemistry : " + mark4 +"<br> </p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(NewServlet1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(NewServlet1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
